影音入库箱 v6.0 · 离线存档
核对日期：2026-11-23
存档人：a-splash-of-water
公钥指纹：SHA256:5HIRWZfB7RppTD0S8S1P6rwPof2FWwS2dykAWOO93xU

这个包不是为了“追新版”，而是把第一次核对需要的东西固定在本地：
以后只打开解压目录里的 HTML，不再从在线版取新文件。站点以后怎么改，都不影响这份副本。

包内文件
--------
app.html                          单文件离线版（与 downloads/ 里的 HTML 同字节）
downloads/yingyin-box-v6.0.html  同一份单文件，保留站点路径
downloads/yingyin-box-v6.0.zip   v6.0 完整包（含使用说明、NFO 示例）
SHA256SUMS                       HTML / zip / app.html 的哈希清单（路径与站点一致）
SHA256SUMS.sig                   对 SHA256SUMS 的 Ed25519 签名
allowed_signers                  验签信任配置，标识 a-splash-of-water
signing-key.pub                  作者公钥
VERIFY.md                        校验与验签命令
SITE-SIGNATURE.md                整站签名与信任链说明

第一次核对（建议断网前做一次，之后存档）
--------
1. 解压到只读目录，保持文件名不变。
2. 校验哈希：
   Windows PowerShell：
     Get-Content .\SHA256SUMS -Encoding UTF8 | ForEach-Object {
       $h,$p = $_ -split '  ',2
       if ((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLower() -ne $h) { throw "BAD $p" }
     }
     "OK"
   macOS / Linux：
     sha256sum -c SHA256SUMS
3. 验签：
   macOS / Linux：
     ssh-keygen -Y verify -f allowed_signers -I a-splash-of-water \
       -n yingyin-box-SHA256SUMS -s SHA256SUMS.sig < SHA256SUMS
   Windows PowerShell：
     cmd /c '"C:\Windows\System32\OpenSSH\ssh-keygen.exe" -Y verify -f allowed_signers -I a-splash-of-water -n yingyin-box-SHA256SUMS -s SHA256SUMS.sig < SHA256SUMS'
   看到 Good "yingyin-box-SHA256SUMS" signature for a-splash-of-water 即通过。
4. 记下核对日期、SHA256SUMS 的 SHA-256、公钥指纹，和这份包放在一起。
5. 以后直接双击 app.html。需要完整包、NFO 示例或说明时再解压 downloads/yingyin-box-v6.0.zip。

第二渠道（仓库）
--------
页面只是入口，不是证据。去仓库看同一份文件和历史：
- https://gitee.com/a-splash-of-water/yingyin-box/blob/master/SHA256SUMS
- https://gitee.com/a-splash-of-water/yingyin-box/commits/master
- https://gitee.com/a-splash-of-water/yingyin-box/tree/master/downloads

两个独立来源（本地存档 + 仓库）对得上，才接近签名带来的可信度。

说明
--------
包内 SHA256SUMS 是 v6.0 发布包快照，用于校验包内 HTML / zip / app.html。
官网根目录的 canonical SHA256SUMS 另外记录了本存档包自身的哈希；两者作用不同，不要混用。
如果包内任一文件被改动，哈希校验会失败；如果 SHA256SUMS 被改动，签名验证会失败。
